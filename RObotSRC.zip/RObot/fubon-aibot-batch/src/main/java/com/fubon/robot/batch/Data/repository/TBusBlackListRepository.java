package com.fubon.robot.batch.Data.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.fubon.robot.batch.robot.evdata.Blacklist;
import com.fubon.robot.batch.robot.evdata.TTmObGroup;

@Repository
public interface TBusBlackListRepository extends JpaRepository<Blacklist, String> {

	public Blacklist findByIdentityIdAndDeleteMarkNotInAndStatusIn(String identityId, List<String> deleteMark,
			List<String> status);

	@Query("select t from Blacklist t where t.identityId = :identitys")
	public Blacklist findRepinBlackList(@Param("identitys") String identity);

}
